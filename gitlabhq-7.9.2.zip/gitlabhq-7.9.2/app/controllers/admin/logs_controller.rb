class Admin::LogsController < Admin::ApplicationController
end
